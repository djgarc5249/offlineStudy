"use strict";
/* Bump CACHE whenever any file changes so phones pick up the update. */
var CACHE="certdrill-v1";
var ASSETS=["./","index.html","styles.css","app.js","subnet.js","manifest.webmanifest","icon-192.png","icon-512.png","apple-touch-icon.png",
 "packs/secplus.js","packs/ccna.js","packs/linuxplus.js","packs/cysa.js","packs/netplus.js"];
self.addEventListener("install",function(e){
  e.waitUntil(caches.open(CACHE).then(function(c){return c.addAll(ASSETS)}).then(function(){return self.skipWaiting()}));
});
self.addEventListener("activate",function(e){
  e.waitUntil(caches.keys().then(function(ks){return Promise.all(ks.filter(function(k){return k!==CACHE}).map(function(k){return caches.delete(k)}))}).then(function(){return self.clients.claim()}));
});
self.addEventListener("fetch",function(e){
  if(e.request.method!=="GET")return;
  e.respondWith(caches.match(e.request,{ignoreSearch:true}).then(function(hit){
    var net=fetch(e.request).then(function(r){
      if(r&&r.ok&&new URL(e.request.url).origin===location.origin){var cp=r.clone();caches.open(CACHE).then(function(c){c.put(e.request,cp)})}
      return r;
    }).catch(function(){return hit||caches.match("index.html")});
    return hit||net;
  }));
});
